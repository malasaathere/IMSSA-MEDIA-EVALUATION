const { Client, Functions } = require('node-appwrite');
const { InputFile } = require('node-appwrite/file');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

async function deploy() {
  const client = new Client()
    .setEndpoint('https://sgp.cloud.appwrite.io/v1')
    .setProject('6a5d22360034431fb3fd')
    .setKey('standard_e741e9312ce1b3c5e313bfb0bce63ed98c8ef121538a3ffa6f8fb837396451652324c29ec189e53c339b760f3be72a2263cba74b241362f85d00d2259f42e62f5855f7b80d0eebd3d2cabb4846306dce0c81ef68a8fde32a8cae315ff4cc7f0e94405612e2d200be816a1abe0244f9a570a70005f924a2f41bf8595b11c404df');

  const functions = new Functions(client);

  const functionId = 'create-user';

  console.log('Checking if function exists...');
  try {
    await functions.get(functionId);
    console.log('Function exists. Updating...');
    await functions.update({
      functionId,
      name: 'create-user',
      runtime: 'node-18.0',
      execute: ['any'],
      events: [],
      schedule: '',
      timeout: 15,
      enabled: true
    });
  } catch (e) {
    if (e.code === 404) {
      console.log('Function does not exist. Creating...');
      await functions.create({
        functionId,
        name: 'create-user',
        runtime: 'node-18.0',
        execute: ['any']
      });
    } else {
      throw e;
    }
  }

  // Set environment variables for the function
  console.log('Setting environment variables...');
  const vars = {
    'APPWRITE_ENDPOINT': 'https://sgp.cloud.appwrite.io/v1',
    'APPWRITE_PROJECT_ID': '6a5d22360034431fb3fd',
    'APPWRITE_API_KEY': 'standard_e741e9312ce1b3c5e313bfb0bce63ed98c8ef121538a3ffa6f8fb837396451652324c29ec189e53c339b760f3be72a2263cba74b241362f85d00d2259f42e62f5855f7b80d0eebd3d2cabb4846306dce0c81ef68a8fde32a8cae315ff4cc7f0e94405612e2d200be816a1abe0244f9a570a70005f924a2f41bf8595b11c404df'
  };

  for (const [key, value] of Object.entries(vars)) {
    try {
      await functions.createVariable({ functionId, variableId: key, key, value });
      console.log(`Created variable ${key}`);
    } catch (e) {
      if (e.code === 409) {
        await functions.updateVariable({ functionId, variableId: key, key, value });
        console.log(`Updated variable ${key}`);
      } else {
        console.error(`Error creating variable ${key}:`, e.message);
      }
    }
  }

  // Create tarball
  console.log('Creating code tarball...');
  const funcDir = path.join(__dirname, 'infra', 'functions', 'createUser');
  const tarPath = path.join(__dirname, 'func.tar.gz');
  execSync(`tar -zcvf func.tar.gz -C . .`);

  // Create deployment
  console.log('Uploading deployment...');
  const deployment = await functions.createDeployment({
    functionId,
    code: InputFile.fromPath(tarPath, 'func.tar.gz'),
    activate: true,
    entrypoint: 'index.js',
    commands: 'npm install'
  });

  console.log('Deployment created successfully!', deployment.$id);
  
  // Wait for build to complete
  let status = 'processing';
  while(status === 'processing' || status === 'building') {
      console.log('Waiting for build... current status:', status);
      await new Promise(r => setTimeout(r, 2000));
      const getDeploy = await functions.getDeployment(functionId, deployment.$id);
      status = getDeploy.status;
  }
  console.log('Final build status:', status);
}

deploy().catch(console.error);
